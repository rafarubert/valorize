create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

DROP INDEX public.unique_schema_migrations;
DROP INDEX public.index_users_on_id;
DROP INDEX public.index_user_plugins_on_title;
DROP INDEX public.index_unique_user_plugins;
DROP INDEX public.index_slugs_on_sluggable_id;
DROP INDEX public.index_slugs_on_n_s_s_and_s;
DROP INDEX public.index_slugs_on_locale;
DROP INDEX public.index_seo_meta_on_seo_meta_id_and_seo_meta_type;
DROP INDEX public.index_seo_meta_on_id;
DROP INDEX public.index_roles_users_on_user_id_and_role_id;
DROP INDEX public.index_roles_users_on_role_id_and_user_id;
DROP INDEX public.index_refinery_settings_on_name;
DROP INDEX public.index_pages_on_rgt;
DROP INDEX public.index_pages_on_parent_id;
DROP INDEX public.index_pages_on_lft;
DROP INDEX public.index_pages_on_id;
DROP INDEX public.index_pages_on_depth;
DROP INDEX public.index_page_translations_on_page_id;
DROP INDEX public.index_page_parts_on_page_id;
DROP INDEX public.index_page_parts_on_id;
DROP INDEX public.index_page_part_translations_on_page_part_id;
DROP INDEX public.index_news_items_on_id;
DROP INDEX public.index_news_item_translations_on_news_item_id;
DROP INDEX public.index_inquiries_on_id;
DROP INDEX public.index_campaigns_on_id;
DROP INDEX public.index_blog_posts_on_id;
DROP INDEX public.index_blog_comments_on_id;
DROP INDEX public.index_blog_categories_on_id;
DROP INDEX public.index_blog_categories_blog_posts_on_bc_and_bp;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.user_plugins DROP CONSTRAINT user_plugins_pkey;
ALTER TABLE ONLY public.slugs DROP CONSTRAINT slugs_pkey;
ALTER TABLE ONLY public.seo_meta DROP CONSTRAINT seo_meta_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.resources DROP CONSTRAINT resources_pkey;
ALTER TABLE ONLY public.refinery_settings DROP CONSTRAINT refinery_settings_pkey;
ALTER TABLE ONLY public.pages DROP CONSTRAINT pages_pkey;
ALTER TABLE ONLY public.page_translations DROP CONSTRAINT page_translations_pkey;
ALTER TABLE ONLY public.page_parts DROP CONSTRAINT page_parts_pkey;
ALTER TABLE ONLY public.page_part_translations DROP CONSTRAINT page_part_translations_pkey;
ALTER TABLE ONLY public.news_items DROP CONSTRAINT news_items_pkey;
ALTER TABLE ONLY public.news_item_translations DROP CONSTRAINT news_item_translations_pkey;
ALTER TABLE ONLY public.inquiry_settings DROP CONSTRAINT inquiry_settings_pkey;
ALTER TABLE ONLY public.inquiries DROP CONSTRAINT inquiries_pkey;
ALTER TABLE ONLY public.images DROP CONSTRAINT images_pkey;
ALTER TABLE ONLY public.campaigns DROP CONSTRAINT campaigns_pkey;
ALTER TABLE ONLY public.blog_posts DROP CONSTRAINT blog_posts_pkey;
ALTER TABLE ONLY public.blog_comments DROP CONSTRAINT blog_comments_pkey;
ALTER TABLE ONLY public.blog_categories DROP CONSTRAINT blog_categories_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_plugins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.slugs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.seo_meta ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.resources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.refinery_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.pages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.page_translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.page_parts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.page_part_translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.news_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.news_item_translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inquiry_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inquiries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.campaigns ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.blog_categories ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.user_plugins_id_seq;
DROP TABLE public.user_plugins;
DROP SEQUENCE public.slugs_id_seq;
DROP TABLE public.slugs;
DROP SEQUENCE public.seo_meta_id_seq;
DROP TABLE public.seo_meta;
DROP TABLE public.schema_migrations;
DROP TABLE public.roles_users;
DROP SEQUENCE public.roles_id_seq;
DROP TABLE public.roles;
DROP SEQUENCE public.resources_id_seq;
DROP TABLE public.resources;
DROP SEQUENCE public.refinery_settings_id_seq;
DROP TABLE public.refinery_settings;
DROP SEQUENCE public.pages_id_seq;
DROP TABLE public.pages;
DROP SEQUENCE public.page_translations_id_seq;
DROP TABLE public.page_translations;
DROP SEQUENCE public.page_parts_id_seq;
DROP TABLE public.page_parts;
DROP SEQUENCE public.page_part_translations_id_seq;
DROP TABLE public.page_part_translations;
DROP SEQUENCE public.news_items_id_seq;
DROP TABLE public.news_items;
DROP SEQUENCE public.news_item_translations_id_seq;
DROP TABLE public.news_item_translations;
DROP SEQUENCE public.inquiry_settings_id_seq;
DROP TABLE public.inquiry_settings;
DROP SEQUENCE public.inquiries_id_seq;
DROP TABLE public.inquiries;
DROP SEQUENCE public.images_id_seq;
DROP TABLE public.images;
DROP SEQUENCE public.campaigns_id_seq;
DROP TABLE public.campaigns;
DROP SEQUENCE public.blog_posts_id_seq;
DROP TABLE public.blog_posts;
DROP SEQUENCE public.blog_comments_id_seq;
DROP TABLE public.blog_comments;
DROP SEQUENCE public.blog_categories_id_seq;
DROP TABLE public.blog_categories_blog_posts;
DROP TABLE public.blog_categories;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: blog_categories; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE blog_categories (
    id integer NOT NULL,
    title character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.blog_categories OWNER TO ruby;

--
-- Name: blog_categories_blog_posts; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE blog_categories_blog_posts (
    blog_category_id integer,
    blog_post_id integer
);


ALTER TABLE public.blog_categories_blog_posts OWNER TO ruby;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE blog_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.blog_categories_id_seq OWNER TO ruby;

--
-- Name: blog_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE blog_categories_id_seq OWNED BY blog_categories.id;


--
-- Name: blog_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('blog_categories_id_seq', 3, true);


--
-- Name: blog_comments; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE blog_comments (
    id integer NOT NULL,
    blog_post_id integer,
    spam boolean,
    name character varying(255),
    email character varying(255),
    body text,
    state character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.blog_comments OWNER TO ruby;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE blog_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.blog_comments_id_seq OWNER TO ruby;

--
-- Name: blog_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE blog_comments_id_seq OWNED BY blog_comments.id;


--
-- Name: blog_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('blog_comments_id_seq', 1, false);


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE blog_posts (
    id integer NOT NULL,
    title character varying(255),
    body text,
    draft boolean,
    published_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    user_id integer
);


ALTER TABLE public.blog_posts OWNER TO ruby;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE blog_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.blog_posts_id_seq OWNER TO ruby;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE blog_posts_id_seq OWNED BY blog_posts.id;


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('blog_posts_id_seq', 8, true);


--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE campaigns (
    id integer NOT NULL,
    subject character varying(255),
    mailchimp_campaign_id character varying(255),
    mailchimp_list_id character varying(255),
    mailchimp_template_id character varying(255),
    from_email character varying(255),
    from_name character varying(255),
    to_name character varying(255),
    body text,
    sent_at timestamp without time zone,
    scheduled_at timestamp without time zone,
    auto_tweet boolean DEFAULT false,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.campaigns OWNER TO ruby;

--
-- Name: campaigns_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE campaigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.campaigns_id_seq OWNER TO ruby;

--
-- Name: campaigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE campaigns_id_seq OWNED BY campaigns.id;


--
-- Name: campaigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('campaigns_id_seq', 1, false);


--
-- Name: images; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE images (
    id integer NOT NULL,
    image_mime_type character varying(255),
    image_name character varying(255),
    image_size integer,
    image_width integer,
    image_height integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    image_uid character varying(255),
    image_ext character varying(255)
);


ALTER TABLE public.images OWNER TO ruby;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.images_id_seq OWNER TO ruby;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE images_id_seq OWNED BY images.id;


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('images_id_seq', 2, true);


--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE inquiries (
    id integer NOT NULL,
    name character varying(255),
    email character varying(255),
    phone character varying(255),
    message text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    spam boolean DEFAULT false
);


ALTER TABLE public.inquiries OWNER TO ruby;

--
-- Name: inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE inquiries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.inquiries_id_seq OWNER TO ruby;

--
-- Name: inquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE inquiries_id_seq OWNED BY inquiries.id;


--
-- Name: inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('inquiries_id_seq', 1, false);


--
-- Name: inquiry_settings; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE inquiry_settings (
    id integer NOT NULL,
    name character varying(255),
    value text,
    destroyable boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.inquiry_settings OWNER TO ruby;

--
-- Name: inquiry_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE inquiry_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.inquiry_settings_id_seq OWNER TO ruby;

--
-- Name: inquiry_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE inquiry_settings_id_seq OWNED BY inquiry_settings.id;


--
-- Name: inquiry_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('inquiry_settings_id_seq', 1, false);


--
-- Name: news_item_translations; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE news_item_translations (
    id integer NOT NULL,
    news_item_id integer,
    locale character varying(255),
    title character varying(255),
    body text,
    external_url character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.news_item_translations OWNER TO ruby;

--
-- Name: news_item_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE news_item_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.news_item_translations_id_seq OWNER TO ruby;

--
-- Name: news_item_translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE news_item_translations_id_seq OWNED BY news_item_translations.id;


--
-- Name: news_item_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('news_item_translations_id_seq', 1, true);


--
-- Name: news_items; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE news_items (
    id integer NOT NULL,
    title character varying(255),
    body text,
    publish_date timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    external_url character varying(255),
    image_id integer
);


ALTER TABLE public.news_items OWNER TO ruby;

--
-- Name: news_items_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE news_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.news_items_id_seq OWNER TO ruby;

--
-- Name: news_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE news_items_id_seq OWNED BY news_items.id;


--
-- Name: news_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('news_items_id_seq', 1, true);


--
-- Name: page_part_translations; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE page_part_translations (
    id integer NOT NULL,
    page_part_id integer,
    locale character varying(255),
    body text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.page_part_translations OWNER TO ruby;

--
-- Name: page_part_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE page_part_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.page_part_translations_id_seq OWNER TO ruby;

--
-- Name: page_part_translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE page_part_translations_id_seq OWNED BY page_part_translations.id;


--
-- Name: page_part_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('page_part_translations_id_seq', 37, true);


--
-- Name: page_parts; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE page_parts (
    id integer NOT NULL,
    page_id integer,
    title character varying(255),
    body text,
    "position" integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.page_parts OWNER TO ruby;

--
-- Name: page_parts_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE page_parts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.page_parts_id_seq OWNER TO ruby;

--
-- Name: page_parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE page_parts_id_seq OWNED BY page_parts.id;


--
-- Name: page_parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('page_parts_id_seq', 37, true);


--
-- Name: page_translations; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE page_translations (
    id integer NOT NULL,
    page_id integer,
    locale character varying(255),
    title character varying(255),
    custom_title character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.page_translations OWNER TO ruby;

--
-- Name: page_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE page_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.page_translations_id_seq OWNER TO ruby;

--
-- Name: page_translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE page_translations_id_seq OWNED BY page_translations.id;


--
-- Name: page_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('page_translations_id_seq', 23, true);


--
-- Name: pages; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE pages (
    id integer NOT NULL,
    parent_id integer,
    "position" integer,
    path character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    show_in_menu boolean DEFAULT true,
    link_url character varying(255),
    menu_match character varying(255),
    deletable boolean DEFAULT true,
    custom_title_type character varying(255) DEFAULT 'none'::character varying,
    draft boolean DEFAULT false,
    skip_to_first_child boolean DEFAULT false,
    lft integer,
    rgt integer,
    depth integer
);


ALTER TABLE public.pages OWNER TO ruby;

--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.pages_id_seq OWNER TO ruby;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE pages_id_seq OWNED BY pages.id;


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('pages_id_seq', 20, true);


--
-- Name: refinery_settings; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE refinery_settings (
    id integer NOT NULL,
    name character varying(255),
    value text,
    destroyable boolean DEFAULT true,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    scoping character varying(255),
    restricted boolean DEFAULT false,
    callback_proc_as_string character varying(255),
    form_value_type character varying(255)
);


ALTER TABLE public.refinery_settings OWNER TO ruby;

--
-- Name: refinery_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE refinery_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.refinery_settings_id_seq OWNER TO ruby;

--
-- Name: refinery_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE refinery_settings_id_seq OWNED BY refinery_settings.id;


--
-- Name: refinery_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('refinery_settings_id_seq', 39, true);


--
-- Name: resources; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE resources (
    id integer NOT NULL,
    file_mime_type character varying(255),
    file_name character varying(255),
    file_size integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    file_uid character varying(255),
    file_ext character varying(255)
);


ALTER TABLE public.resources OWNER TO ruby;

--
-- Name: resources_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE resources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.resources_id_seq OWNER TO ruby;

--
-- Name: resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE resources_id_seq OWNED BY resources.id;


--
-- Name: resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('resources_id_seq', 1, false);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE roles (
    id integer NOT NULL,
    title character varying(255)
);


ALTER TABLE public.roles OWNER TO ruby;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO ruby;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE roles_id_seq OWNED BY roles.id;


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('roles_id_seq', 2, true);


--
-- Name: roles_users; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE roles_users (
    user_id integer,
    role_id integer
);


ALTER TABLE public.roles_users OWNER TO ruby;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO ruby;

--
-- Name: seo_meta; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE seo_meta (
    id integer NOT NULL,
    seo_meta_id integer,
    seo_meta_type character varying(255),
    browser_title character varying(255),
    meta_keywords character varying(255),
    meta_description text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.seo_meta OWNER TO ruby;

--
-- Name: seo_meta_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE seo_meta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.seo_meta_id_seq OWNER TO ruby;

--
-- Name: seo_meta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE seo_meta_id_seq OWNED BY seo_meta.id;


--
-- Name: seo_meta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('seo_meta_id_seq', 1, false);


--
-- Name: slugs; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE slugs (
    id integer NOT NULL,
    name character varying(255),
    sluggable_id integer,
    sequence integer DEFAULT 1 NOT NULL,
    sluggable_type character varying(40),
    scope character varying(40),
    created_at timestamp without time zone,
    locale character varying(255)
);


ALTER TABLE public.slugs OWNER TO ruby;

--
-- Name: slugs_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE slugs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.slugs_id_seq OWNER TO ruby;

--
-- Name: slugs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE slugs_id_seq OWNED BY slugs.id;


--
-- Name: slugs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('slugs_id_seq', 41, true);


--
-- Name: user_plugins; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE user_plugins (
    id integer NOT NULL,
    user_id integer,
    name character varying(255),
    "position" integer
);


ALTER TABLE public.user_plugins OWNER TO ruby;

--
-- Name: user_plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE user_plugins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.user_plugins_id_seq OWNER TO ruby;

--
-- Name: user_plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE user_plugins_id_seq OWNED BY user_plugins.id;


--
-- Name: user_plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('user_plugins_id_seq', 40, true);


--
-- Name: users; Type: TABLE; Schema: public; Owner: ruby; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    encrypted_password character varying(255) NOT NULL,
    persistence_token character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    perishable_token character varying(255),
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying(255),
    last_sign_in_ip character varying(255),
    sign_in_count integer,
    remember_token character varying(255),
    reset_password_token character varying(255),
    remember_created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO ruby;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ruby
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO ruby;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ruby
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ruby
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE blog_categories ALTER COLUMN id SET DEFAULT nextval('blog_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE blog_comments ALTER COLUMN id SET DEFAULT nextval('blog_comments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE blog_posts ALTER COLUMN id SET DEFAULT nextval('blog_posts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE campaigns ALTER COLUMN id SET DEFAULT nextval('campaigns_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE images ALTER COLUMN id SET DEFAULT nextval('images_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE inquiries ALTER COLUMN id SET DEFAULT nextval('inquiries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE inquiry_settings ALTER COLUMN id SET DEFAULT nextval('inquiry_settings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE news_item_translations ALTER COLUMN id SET DEFAULT nextval('news_item_translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE news_items ALTER COLUMN id SET DEFAULT nextval('news_items_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE page_part_translations ALTER COLUMN id SET DEFAULT nextval('page_part_translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE page_parts ALTER COLUMN id SET DEFAULT nextval('page_parts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE page_translations ALTER COLUMN id SET DEFAULT nextval('page_translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE pages ALTER COLUMN id SET DEFAULT nextval('pages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE refinery_settings ALTER COLUMN id SET DEFAULT nextval('refinery_settings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE resources ALTER COLUMN id SET DEFAULT nextval('resources_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE seo_meta ALTER COLUMN id SET DEFAULT nextval('seo_meta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE slugs ALTER COLUMN id SET DEFAULT nextval('slugs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE user_plugins ALTER COLUMN id SET DEFAULT nextval('user_plugins_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: ruby
--

ALTER TABLE users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: blog_categories; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY blog_categories (id, title, created_at, updated_at) FROM stdin;
\.
copy blog_categories (id, title, created_at, updated_at)  from '$$PATH$$/2009.dat' ;
--
-- Data for Name: blog_categories_blog_posts; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY blog_categories_blog_posts (blog_category_id, blog_post_id) FROM stdin;
\.
copy blog_categories_blog_posts (blog_category_id, blog_post_id)  from '$$PATH$$/2010.dat' ;
--
-- Data for Name: blog_comments; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY blog_comments (id, blog_post_id, spam, name, email, body, state, created_at, updated_at) FROM stdin;
\.
copy blog_comments (id, blog_post_id, spam, name, email, body, state, created_at, updated_at)  from '$$PATH$$/2008.dat' ;
--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY blog_posts (id, title, body, draft, published_at, created_at, updated_at, user_id) FROM stdin;
\.
copy blog_posts (id, title, body, draft, published_at, created_at, updated_at, user_id)  from '$$PATH$$/2007.dat' ;
--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY campaigns (id, subject, mailchimp_campaign_id, mailchimp_list_id, mailchimp_template_id, from_email, from_name, to_name, body, sent_at, scheduled_at, auto_tweet, created_at, updated_at) FROM stdin;
\.
copy campaigns (id, subject, mailchimp_campaign_id, mailchimp_list_id, mailchimp_template_id, from_email, from_name, to_name, body, sent_at, scheduled_at, auto_tweet, created_at, updated_at)  from '$$PATH$$/2006.dat' ;
--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY images (id, image_mime_type, image_name, image_size, image_width, image_height, created_at, updated_at, image_uid, image_ext) FROM stdin;
\.
copy images (id, image_mime_type, image_name, image_size, image_width, image_height, created_at, updated_at, image_uid, image_ext)  from '$$PATH$$/1997.dat' ;
--
-- Data for Name: inquiries; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY inquiries (id, name, email, phone, message, created_at, updated_at, spam) FROM stdin;
\.
copy inquiries (id, name, email, phone, message, created_at, updated_at, spam)  from '$$PATH$$/2011.dat' ;
--
-- Data for Name: inquiry_settings; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY inquiry_settings (id, name, value, destroyable, created_at, updated_at) FROM stdin;
\.
copy inquiry_settings (id, name, value, destroyable, created_at, updated_at)  from '$$PATH$$/2012.dat' ;
--
-- Data for Name: news_item_translations; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY news_item_translations (id, news_item_id, locale, title, body, external_url, created_at, updated_at) FROM stdin;
\.
copy news_item_translations (id, news_item_id, locale, title, body, external_url, created_at, updated_at)  from '$$PATH$$/2005.dat' ;
--
-- Data for Name: news_items; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY news_items (id, title, body, publish_date, created_at, updated_at, external_url, image_id) FROM stdin;
\.
copy news_items (id, title, body, publish_date, created_at, updated_at, external_url, image_id)  from '$$PATH$$/2004.dat' ;
--
-- Data for Name: page_part_translations; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY page_part_translations (id, page_part_id, locale, body, created_at, updated_at) FROM stdin;
\.
copy page_part_translations (id, page_part_id, locale, body, created_at, updated_at)  from '$$PATH$$/2000.dat' ;
--
-- Data for Name: page_parts; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY page_parts (id, page_id, title, body, "position", created_at, updated_at) FROM stdin;
\.
copy page_parts (id, page_id, title, body, "position", created_at, updated_at)  from '$$PATH$$/1998.dat' ;
--
-- Data for Name: page_translations; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY page_translations (id, page_id, locale, title, custom_title, created_at, updated_at) FROM stdin;
\.
copy page_translations (id, page_id, locale, title, custom_title, created_at, updated_at)  from '$$PATH$$/2001.dat' ;
--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY pages (id, parent_id, "position", path, created_at, updated_at, show_in_menu, link_url, menu_match, deletable, custom_title_type, draft, skip_to_first_child, lft, rgt, depth) FROM stdin;
\.
copy pages (id, parent_id, "position", path, created_at, updated_at, show_in_menu, link_url, menu_match, deletable, custom_title_type, draft, skip_to_first_child, lft, rgt, depth)  from '$$PATH$$/1999.dat' ;
--
-- Data for Name: refinery_settings; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY refinery_settings (id, name, value, destroyable, created_at, updated_at, scoping, restricted, callback_proc_as_string, form_value_type) FROM stdin;
\.
copy refinery_settings (id, name, value, destroyable, created_at, updated_at, scoping, restricted, callback_proc_as_string, form_value_type)  from '$$PATH$$/1992.dat' ;
--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY resources (id, file_mime_type, file_name, file_size, created_at, updated_at, file_uid, file_ext) FROM stdin;
\.
copy resources (id, file_mime_type, file_name, file_size, created_at, updated_at, file_uid, file_ext)  from '$$PATH$$/2003.dat' ;
--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY roles (id, title) FROM stdin;
\.
copy roles (id, title)  from '$$PATH$$/1994.dat' ;
--
-- Data for Name: roles_users; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY roles_users (user_id, role_id) FROM stdin;
\.
copy roles_users (user_id, role_id)  from '$$PATH$$/1993.dat' ;
--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY schema_migrations (version) FROM stdin;
\.
copy schema_migrations (version)  from '$$PATH$$/1990.dat' ;
--
-- Data for Name: seo_meta; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY seo_meta (id, seo_meta_id, seo_meta_type, browser_title, meta_keywords, meta_description, created_at, updated_at) FROM stdin;
\.
copy seo_meta (id, seo_meta_id, seo_meta_type, browser_title, meta_keywords, meta_description, created_at, updated_at)  from '$$PATH$$/2002.dat' ;
--
-- Data for Name: slugs; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY slugs (id, name, sluggable_id, sequence, sluggable_type, scope, created_at, locale) FROM stdin;
\.
copy slugs (id, name, sluggable_id, sequence, sluggable_type, scope, created_at, locale)  from '$$PATH$$/1991.dat' ;
--
-- Data for Name: user_plugins; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY user_plugins (id, user_id, name, "position") FROM stdin;
\.
copy user_plugins (id, user_id, name, "position")  from '$$PATH$$/1995.dat' ;
--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ruby
--

COPY users (id, username, email, encrypted_password, persistence_token, created_at, updated_at, perishable_token, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, sign_in_count, remember_token, reset_password_token, remember_created_at) FROM stdin;
\.
copy users (id, username, email, encrypted_password, persistence_token, created_at, updated_at, perishable_token, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, sign_in_count, remember_token, reset_password_token, remember_created_at)  from '$$PATH$$/1996.dat' ;
--
-- Name: blog_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY blog_categories
    ADD CONSTRAINT blog_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY blog_comments
    ADD CONSTRAINT blog_comments_pkey PRIMARY KEY (id);


--
-- Name: blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: images_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: inquiry_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY inquiry_settings
    ADD CONSTRAINT inquiry_settings_pkey PRIMARY KEY (id);


--
-- Name: news_item_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY news_item_translations
    ADD CONSTRAINT news_item_translations_pkey PRIMARY KEY (id);


--
-- Name: news_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY news_items
    ADD CONSTRAINT news_items_pkey PRIMARY KEY (id);


--
-- Name: page_part_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY page_part_translations
    ADD CONSTRAINT page_part_translations_pkey PRIMARY KEY (id);


--
-- Name: page_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY page_parts
    ADD CONSTRAINT page_parts_pkey PRIMARY KEY (id);


--
-- Name: page_translations_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY page_translations
    ADD CONSTRAINT page_translations_pkey PRIMARY KEY (id);


--
-- Name: pages_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: refinery_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY refinery_settings
    ADD CONSTRAINT refinery_settings_pkey PRIMARY KEY (id);


--
-- Name: resources_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: seo_meta_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY seo_meta
    ADD CONSTRAINT seo_meta_pkey PRIMARY KEY (id);


--
-- Name: slugs_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY slugs
    ADD CONSTRAINT slugs_pkey PRIMARY KEY (id);


--
-- Name: user_plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY user_plugins
    ADD CONSTRAINT user_plugins_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: ruby; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_blog_categories_blog_posts_on_bc_and_bp; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_blog_categories_blog_posts_on_bc_and_bp ON blog_categories_blog_posts USING btree (blog_category_id, blog_post_id);


--
-- Name: index_blog_categories_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_blog_categories_on_id ON blog_categories USING btree (id);


--
-- Name: index_blog_comments_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_blog_comments_on_id ON blog_comments USING btree (id);


--
-- Name: index_blog_posts_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_blog_posts_on_id ON blog_posts USING btree (id);


--
-- Name: index_campaigns_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_campaigns_on_id ON campaigns USING btree (id);


--
-- Name: index_inquiries_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_inquiries_on_id ON inquiries USING btree (id);


--
-- Name: index_news_item_translations_on_news_item_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_news_item_translations_on_news_item_id ON news_item_translations USING btree (news_item_id);


--
-- Name: index_news_items_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_news_items_on_id ON news_items USING btree (id);


--
-- Name: index_page_part_translations_on_page_part_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_page_part_translations_on_page_part_id ON page_part_translations USING btree (page_part_id);


--
-- Name: index_page_parts_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_page_parts_on_id ON page_parts USING btree (id);


--
-- Name: index_page_parts_on_page_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_page_parts_on_page_id ON page_parts USING btree (page_id);


--
-- Name: index_page_translations_on_page_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_page_translations_on_page_id ON page_translations USING btree (page_id);


--
-- Name: index_pages_on_depth; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_pages_on_depth ON pages USING btree (depth);


--
-- Name: index_pages_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_pages_on_id ON pages USING btree (id);


--
-- Name: index_pages_on_lft; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_pages_on_lft ON pages USING btree (lft);


--
-- Name: index_pages_on_parent_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_pages_on_parent_id ON pages USING btree (parent_id);


--
-- Name: index_pages_on_rgt; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_pages_on_rgt ON pages USING btree (rgt);


--
-- Name: index_refinery_settings_on_name; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_refinery_settings_on_name ON refinery_settings USING btree (name);


--
-- Name: index_roles_users_on_role_id_and_user_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_roles_users_on_role_id_and_user_id ON roles_users USING btree (role_id, user_id);


--
-- Name: index_roles_users_on_user_id_and_role_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_roles_users_on_user_id_and_role_id ON roles_users USING btree (user_id, role_id);


--
-- Name: index_seo_meta_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_seo_meta_on_id ON seo_meta USING btree (id);


--
-- Name: index_seo_meta_on_seo_meta_id_and_seo_meta_type; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_seo_meta_on_seo_meta_id_and_seo_meta_type ON seo_meta USING btree (seo_meta_id, seo_meta_type);


--
-- Name: index_slugs_on_locale; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_slugs_on_locale ON slugs USING btree (locale);


--
-- Name: index_slugs_on_n_s_s_and_s; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE UNIQUE INDEX index_slugs_on_n_s_s_and_s ON slugs USING btree (name, sluggable_type, scope, sequence);


--
-- Name: index_slugs_on_sluggable_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_slugs_on_sluggable_id ON slugs USING btree (sluggable_id);


--
-- Name: index_unique_user_plugins; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE UNIQUE INDEX index_unique_user_plugins ON user_plugins USING btree (user_id, name);


--
-- Name: index_user_plugins_on_title; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_user_plugins_on_title ON user_plugins USING btree (name);


--
-- Name: index_users_on_id; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE INDEX index_users_on_id ON users USING btree (id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: ruby; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

